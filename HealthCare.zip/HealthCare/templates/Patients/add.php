<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Patient $patient
 */
?>


<style>
    /* label {
    width: 66px;
    padding-right: 32px;
} */
.contact_section .form_container button {
    
    background-color: #000000;
}
</style> 


<div class="hero_area">

<div class="hero_bg_box">
<?php echo $this->Html->image('hero-bg.png') ?>
  <img src="images/hero-bg.png" alt="">
</div>
<section class="contact_section layout_padding">
    <div class="container">
      <div class="heading_container">
        <h2>
          Get In Touch
        </h2>
      </div>
      <div class="row">
        <div class="col-md-12">
          <div class="form_container contact-form">
          <?= $this->Form->create($patient) ?>
              <div class="form-row">
                <div class="col-lg-6">
                  <div>
                    <?php echo $this->Form->control('first_name',['placeholder'=>'Enter Your First Name']); ?>
                  </div>
                </div>
                <div class="col-lg-6">
                  <div>
                  <?php echo $this->Form->control('last_name',['placeholder'=>'Enter Your Last Name']); ?>
                  </div>
                </div>
              </div>
              
              <div>
              <div class="form-row">
                <div class="col-lg-6">
                  <div>
                    <?php echo $this->Form->control('email',['placeholder'=>'Enter Your Email']); ?>
                  </div>
                </div>
                <div class="col-lg-6">
                  <div>
                  <?php echo $this->Form->control('phone_no',['placeholder'=>'Enter Phone Number']); ?>
                  </div>
                </div>
              </div>
              <div class="form-row">
                <div class="col-lg-6">
                  <div>
                    <?php echo $this->Form->control('address',['placeholder'=>'Enter Your Address']); ?>
                  </div>
                </div>
                <div class="col-lg-6">
                    <label for="dob">Date of birth</label>
                  <div>
                  <?php echo $this->Form->date('dob'); ?>
                  <?php  ?>
                  </div>
                </div>
              </div>
              <div class="form-row">
                <div class="col-lg-6">
                <label for="gender">Gender</label>
                  <div>
                  <?php echo  $this->Form->radio('gender', ['Male', 'Female', 'Other'],['id'=>'test']);?>

                  </div>
                </div>
                <div class="col-lg-6">
                <label for="message">Message</label>
                  <div>
                    <?php echo $this->Form->textarea('message', ['rows' => '3', 'cols' => '60','placeholder'=>'Enter Your Problems'],); ?>  
                </div>
                </div>
              </div>
             
              </div>
              <div class="btn_box">
                <?= $this->Form->button(__('Submit')) ?>

              </div>
              <?= $this->Form->end() ?>
          </div>
        </div>
</section>

</div>